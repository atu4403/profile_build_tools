# -*- coding: utf-8 -*-
from setuptools import setup

package_dir = \
{'': 'src'}

packages = \
['profile_build_tools']

package_data = \
{'': ['*']}

install_requires = \
['Pillow>=8.1.2,<9.0.0', 'arrow>=1.0.3,<2.0.0', 'selenium>=3.141.0,<4.0.0']

setup_kwargs = {
    'name': 'profile-build-tools',
    'version': '0.1.0',
    'description': 'APIからREADMEを自動作成するtools',
    'long_description': None,
    'author': 'atu4403',
    'author_email': '73111778+atu4403@users.noreply.github.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'package_dir': package_dir,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
